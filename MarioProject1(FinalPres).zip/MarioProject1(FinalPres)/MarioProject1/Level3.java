
import mayflower.*;
public class Level3 extends World
{
    private ladder Sliddy, Sliddy2, Sliddy3;
    private Mario mario;
    private pipe pipe; 
    private gumba Ojas, Ojas2;
    public Level3()
    {
        setBackground("characters/backgrounds/LevelThreeBackground.png");
        String[][] tiles = new String[9][12];
        showText("Coins needed: 9", 10, 60, Color.BLACK);
        Mayflower.showBounds(true);
        buildLevel3(tiles);
        mario = new Mario();
        Sliddy = new ladder();
        Sliddy2 = new ladder();
        Sliddy3 = new ladder();
        pipe = new pipe();
        Ojas = new gumba();
        Ojas2 = new gumba();
        addObject(mario, 100,100);
        addObject(Sliddy,200,300);
        addObject(Sliddy2,450,100);
        addObject(Sliddy3,500,300);
        addObject(Ojas,250,300);
        addObject(Ojas2,700,550);
        addObject(pipe,800,100);
    }
    public void buildLevel3(String[][] tiles)
    {
        for( int i = 0; i < tiles.length; i++)
        {
            for( int j = 0; j < tiles[i].length; j++)
            {
                tiles[i][j] = "";
            }
        }
        for(int j = 0; j < tiles[8].length; j++)
        {
            tiles[8][j] = "ground";
        }
        for(int b = 0; b < 4; b++)
        {
            tiles[2][b+6] = "ground";
        }
        for(int b = 0; b < 3; b++)
        {
            tiles[7][b+3] = "ground";
            tiles[6][b+3] = "ground";
            tiles[5][b+3] = "ground";
        }
        for(int c = 0; c < 8; c++)
        {
            int rand = (int)(Math.random() * 4) + 7;
            tiles[6][rand] = "coin";
        }
         for(int c = 0; c < 7; c++)
        {
            int rand = (int)(Math.random() * 4) + 5;
            tiles[1][rand] = "coin";
        }
         for(int r = 0; r < tiles.length; r++)
        {
            for( int c = 0; c < tiles[r].length; c++)
            {
                if (tiles[r][c].equals("ground"))
                    {
                        addObject(new bricks(), c*84, r*80);
                    }
                if (tiles[r][c].equals("coin"))
                    {
                        addObject(new coin(), c*84, r*80);
                    }
            }
        }
    }
    public void act()
    {

    }
}
