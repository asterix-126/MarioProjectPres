import mayflower.*;
public class MoveableAnimatedActor extends AnimatedActor
{
    private Animation idleRight;
    private Animation idleLeft;
    private Animation walkRight;
    private Animation walkLeft;
    private Animation fallRight;
    private Animation fallLeft;
    private Animation climb;
    private String currentAction;
    private String direction;


    public MoveableAnimatedActor() {

        direction = "right";
    }

    public void setAnimation(Animation a) {
        super.setAnimation(a);
    }


    public void setIdleRightAnimation(Animation ani) {
        idleRight = ani;
    }
    
    public void setClimbAnimation(Animation ani) {
        climb = ani;
    }

    public void setIdleLeftAnimation(Animation ani) {
        idleLeft = ani;
    }

    public void setWalkRightAnimation(Animation ani) {
        walkRight = ani;
    }

    public void setWalkLeftAnimation(Animation ani) {
        walkLeft = ani;
    }

    public void setFallRightAnimation(Animation ani) {
        fallRight = ani;
    }

    public void setFallLeftAnimation(Animation ani) {
        fallLeft = ani;
    }

    public void act() {
        super.act();

        int x = getX();
        int y = getY();
        int w = getWidth();
        int h = getHeight();
        String newAction = null;

        if(currentAction == null) {
            newAction = "idle";
        }

        if(Mayflower.isKeyDown(Keyboard.KEY_RIGHT) && x < 950 - w) {
            setLocation(x + 2, y);
            if(isBlocked()) {
                setLocation(x, y);
            }
            newAction = "walkRight";
            direction = "right";
        }
        else if(Mayflower.isKeyDown(Keyboard.KEY_LEFT) && x > 0) {
            setLocation(x - 2, y);
            if(isBlocked()) {
                setLocation(x, y);
            }
            newAction = "walkLeft";
            direction = "left";
        }
        else if(Mayflower.isKeyPressed(Keyboard.KEY_UP) && !isFalling() && !isTouching(ladder.class))
        {   
            setLocation(x, y + 10);
            if (isTouching(bricks.class)) 
            {
                setLocation(x, y - 70);
            }
        }
        else if(Mayflower.isKeyDown(Keyboard.KEY_UP) && y > 0) 
        {
            
            if(isTouching(ladder.class))
            {
                setLocation(x, y - 5);
            }
        }
        else if(Mayflower.isKeyDown(Keyboard.KEY_DOWN) && y < 720 - h) {
            setLocation(x, y + 1);

            if(isBlocked()) {
                setLocation(x, y);
            }
        } 
        else 
        {
            newAction = "idleRight";
            if(direction != null && direction.equals("left")) 
            {
                newAction = "idleLeft";
            }
        }

        if(isFalling()) {
            newAction = "fallRight";

            if(direction != null && direction.equals("left")) {
                newAction = "fallLeft";
            }
        }

        if(newAction != null && !newAction.equals(currentAction)) {

            if(newAction.equals("idleRight")) {

                setAnimation(idleRight);
        

            } else if(newAction.equals("idleLeft")) {
                
                setAnimation(idleLeft);
          

            } else if(newAction.equals("fallRight")) {

                setAnimation(fallRight);
        

            } else if(newAction.equals("fallLeft")) {

                setAnimation(fallLeft);
        

            } else if(newAction.equals("walkRight")) {

                setAnimation(walkRight);


            } else if(newAction.equals("walkLeft")) {

                setAnimation(walkLeft);


            }
            
            currentAction = newAction;
        }
    }
    

}
