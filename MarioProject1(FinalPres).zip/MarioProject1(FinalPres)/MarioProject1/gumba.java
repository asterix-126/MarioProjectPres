import mayflower.*;

public class gumba extends AnimatedActor
{
    private Animation walkRight, walkLeft;
    private int counter;
    private Timer pause;
    public gumba()
    {
        String[] walkFiles = new String[2];
        for (int i = 0; i<walkFiles.length; i++)
        {
           walkFiles[i] = new String("characters/gumba/gumbaWalk(" + (i) + ").png"); 
        }
        walkRight = new Animation(50, walkFiles);
        
        walkLeft = new Animation(50, walkFiles);
        walkLeft.mirrorHorizontally();
        
        
        setAnimation(walkRight);
        counter = Math.random() < 0.5 ? 0 : -1;
        pause = new Timer((int) (Math.random() * 1000));        
    }
    public void act()
    {
       super.act();
       
       if (counter >= 100)
       {
            counter = -1;   
       }
       if (counter < -100)
       {
           counter = 0;
       }
       if (pause.isDone())
       {
           pause.reset();
           if (counter >= 0)
           {
               setAnimation(walkRight);
               setLocation(getX() + 2, getY());
               counter++;
           }
           else
           {
               setAnimation(walkLeft);
               setLocation(getX() - 2, getY());
               counter--;
           }
       }
       
       if (isTouching(Mario.class))
       {
           Object a = getOneIntersectingObject(Mario.class);
           Mario mario = (Mario) a;
           
           if (mario.getY() + 100 < getY())
           {
               getWorld().removeObject(this);
               mario.increaseScore(2);
           }
           else 
           {
               mario.setLocation(100,100);
               mario.decreaseLives(1);
           }
           
       }
    }
}
