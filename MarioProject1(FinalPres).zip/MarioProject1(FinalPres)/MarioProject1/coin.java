import mayflower.*;

public class coin extends Actor
{
    public coin()
    {
        setImage("characters/items/coin.png");
    }
    public void act()
    {
        if(isTouching(Mario.class))
        {
            Object c = getOneIntersectingObject(Mario.class);
            Mario a = (Mario) c;
            World w = getWorld();
            w.removeObject(this);
            a.increaseScore(1);
        }
 
    }
}
