import mayflower.*;
public class GameLose extends World
{
    /**
     * Constructor for objects of class GameLose
     */
    public GameLose()
    {
        setBackground("");
        
    }
    public void act()
    {
        if (Mayflower.isKeyPressed(Keyboard.KEY_SPACE))
        {
            Mayflower.setWorld(new Title());
        }
    }
}
