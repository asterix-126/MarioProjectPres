import mayflower.*;
public class Level2 extends World
{
    private ladder Sliddy;
    private Mario mario;
    private pipe pipe; 
    private gumba Ojas;
    public Level2()
    {
        setBackground("characters/backgrounds/LevelTwoBackground.png");
        String[][] tiles = new String[9][12];
        buildLevel2(tiles);
        Ojas = new gumba();
        Sliddy = new ladder();
        mario = new Mario();
        pipe = new pipe();
        mario.setLevel(2);
        addObject(mario, 100,100);
        addObject(Ojas, 500, 500);
        addObject(pipe, 800,500);
        addObject(Sliddy, 500, 300);
        showText("Coins needed: 5", 10, 60, Color.BLACK);
        Mayflower.showBounds(true);
    }
    public void buildLevel2(String[][] tiles)
    {
        for( int i = 0; i < tiles.length; i++)
        {
            for( int j = 0; j < tiles[i].length; j++)
            {
                tiles[i][j] = "";
            }
        }
        for(int j = 0; j < tiles[8].length; j++)
        {
            tiles[8][j] = "ground";
        }
        for(int b = 0; b < 4; b++)
        {
            tiles[4][b+2] = "ground";
        }
        for(int c = 0; c < 6; c++)
        {
            int rand = (int)(Math.random() * 5);
            tiles[5][rand] = "coin";
        }
         for(int c = 0; c < 7; c++)
        {
            int rand = (int)(Math.random() * 3) + 3;
            tiles[1][rand] = "coin";
        }
         for(int r = 0; r < tiles.length; r++)
        {
            for( int c = 0; c < tiles[r].length; c++)
            {
                if (tiles[r][c].equals("ground"))
                    {
                        addObject(new bricks(), c*84, r*80);
                    }
                if (tiles[r][c].equals("coin"))
                    {
                        addObject(new coin(), c*84, r*80);
                    }
            }
        }
    }

    public void act()
    {
        
    }
}
