import mayflower.*;
public class MarioProjectRunner
{

    /**
     * Constructor for objects of class MarioProjectRunner
     */
    public static void main(String[] args)
    {
        new MyMayflower();
    }

}
