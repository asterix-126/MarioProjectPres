import mayflower.*;
public class GameWin extends World
{

    public GameWin()
    {
        setBackground(""); 
    }

    /**
     * An example of a method - replace this comment with your own
     *
     * @param  y  a sample parameter for a method
     * @return    the sum of x and y
     */
    public void act()
    {
        if (Mayflower.isKeyPressed(Keyboard.KEY_SPACE))
        {
            Mayflower.setWorld(new Title());
        } 
    }
}
