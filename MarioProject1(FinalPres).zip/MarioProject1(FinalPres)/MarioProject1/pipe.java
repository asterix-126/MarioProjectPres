import mayflower.*;
/**
 * Write a description of class pipe here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class pipe extends Actor
{
    public pipe()
    {
        setImage("characters/items/pipe.png");
    }
    public void act()
    {
 
    }
}
