import mayflower.*;
public class Title extends World
{

    public Title()
    {
        setBackground("characters/backgrounds/TitleScreen.jpg");
    }
    public void act()
    {
        if (Mayflower.isKeyPressed(Keyboard.KEY_SPACE))
        {
            Mayflower.setWorld(new Level1());
        }

    }
}
